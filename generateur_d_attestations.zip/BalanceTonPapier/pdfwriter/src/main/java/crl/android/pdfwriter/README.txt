Android PDF Writer
http://coderesearchlabs.com/androidpdfwriter

DESCRIPTION
-----------
Android PDF Writer (APW) is a simple Java library to generate simple PDF documents in Google's Android devices released under the BSD license.

For more details, check the included documentation.

Enjoy,
Javier Santo Domingo
j-a-s-d@coderesearchlabs.com
